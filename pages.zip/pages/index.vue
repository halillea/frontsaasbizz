<template>
  <div class="min-h-screen bg-[#F9FAFB] font-sans text-slate-800">
    
    <div class="bg-slate-900 text-white py-6 px-4 text-center border-b border-slate-800 relative z-50">
      <a href="https://saasitron.com" target="_blank" class="group flex flex-col md:flex-row items-center justify-center gap-3 hover:text-blue-200 transition-colors">
        <span class="bg-blue-600 text-white text-xs font-bold px-2 py-1 rounded uppercase tracking-wide">Main Sponsor</span>
        <span class="text-base md:text-lg font-medium">
          <span class="font-bold text-blue-400">SAASitron:</span> 
          Stop coding from scratch. Ship your SaaS in days with the ultimate boilerplate & SDK kit.
        </span>
        <span class="group-hover:translate-x-1 transition-transform text-lg">→</span>
      </a>
    </div>

    <header class="bg-white border-b border-gray-200 sticky top-0 z-40 backdrop-blur-md bg-white/90">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        <div class="flex items-center gap-2">
          <div class="w-8 h-8 bg-blue-600 rounded flex items-center justify-center text-white font-bold shadow-sm shadow-blue-200">S</div>
          <span class="text-xl font-bold tracking-tight text-slate-900">SaaSBizz</span>
        </div>
        
        <div class="hidden md:block max-w-md w-full mx-8">
          <div class="relative">
            <input 
              v-model="search" 
              type="text" 
              placeholder="Search 505+ verified startups..." 
              class="w-full pl-10 pr-4 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
            >
            <span class="absolute left-3 top-2.5 text-gray-400">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
            </span>
          </div>
        </div>

        <nav class="hidden md:flex gap-6 text-sm font-medium text-gray-600">
          <a href="#" class="hover:text-blue-600">Leaderboard</a>
          <NuxtLink to="/submit" class="hover:text-blue-600">Submit</NuxtLink>
          <button class="text-blue-600 bg-blue-50 px-3 py-1.5 rounded-md hover:bg-blue-100 transition-colors">Advertise</button>
        </nav>
      </div>
    </header>

    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">

        <aside class="hidden lg:block lg:col-span-2 space-y-4 sticky top-24">
          <div class="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2">Sponsored</div>
          <Transition name="fade" mode="out-in">
            <div :key="adGroupIndex" class="space-y-4">
              <div v-for="ad in currentLeftAds" :key="ad.id">
                 <a href="#" class="block p-3 rounded-lg border border-blue-100 hover:shadow-md transition-all group" :style="{ backgroundColor: ad.bg }">
                    <div class="flex items-center gap-2 mb-1.5">
                      <span class="text-lg">{{ ad.emoji }}</span>
                      <span class="font-bold text-xs text-gray-900 group-hover:text-blue-700">{{ ad.name }}</span>
                    </div>
                    <p class="text-[11px] leading-snug text-slate-600">{{ ad.copy }}</p>
                 </a>
              </div>
            </div>
          </Transition>
        </aside>

        <section class="col-span-1 lg:col-span-8 bg-gradient-to-br from-emerald-50 to-sky-50 rounded-3xl p-6 border border-slate-200/60 shadow-sm">
          
          <div class="flex flex-col md:flex-row justify-between items-center gap-4 mb-6 pb-4 border-b border-gray-200/50">
            
            <div class="flex flex-wrap gap-2">
              <button 
                @click="activeCategory = 'All'"
                :class="activeCategory === 'All' ? 'bg-slate-900 text-white' : 'bg-white text-gray-600 hover:bg-gray-50 border border-gray-200'"
                class="px-3 py-1.5 rounded-full text-xs font-semibold transition-colors shadow-sm uppercase"
              >
                All
              </button>
              
              <button 
                v-for="cat in navCategories" 
                :key="cat.original"
                @click="activeCategory = cat.original"
                :class="activeCategory === cat.original ? 'bg-slate-900 text-white' : 'bg-white text-gray-600 hover:bg-gray-50 border border-gray-200'"
                class="px-3 py-1.5 rounded-full text-xs font-semibold uppercase transition-colors shadow-sm"
              >
                {{ cat.display }}
              </button>
            </div>

            <div class="flex items-center gap-2 bg-white px-3 py-1.5 rounded-lg border border-gray-200 shadow-sm">
                <span class="text-xs text-gray-400 font-bold uppercase">Sort:</span>
                <select v-model="sortBy" class="text-xs font-semibold text-gray-700 bg-transparent outline-none cursor-pointer">
                    <option value="MRR">MRR</option>
                    <option value="Total Revenue">Total Revenue</option>
                </select>
            </div>

          </div>

          <div class="space-y-2"> 
            <StartupCard 
              v-for="(startup, index) in filteredStartups" 
              :key="startup.domain" 
              :startup="startup"
              :rank="index + 1"
              :sortBy="sortBy"
            />
            
            <div v-if="filteredStartups.length === 0" class="text-center py-20 text-gray-500">
              <p>No startups found matching your criteria.</p>
              <button @click="resetFilters" class="mt-2 text-blue-600 font-medium hover:underline">Clear filters</button>
            </div>
          </div>
        </section>

        <aside class="hidden lg:block lg:col-span-2 space-y-4 sticky top-24">
          <div class="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2">Featured Tools</div>
          <Transition name="fade" mode="out-in">
            <div :key="adGroupIndex" class="space-y-4">
              <div v-for="ad in currentRightAds" :key="ad.id">
                 <a href="#" class="block p-3 rounded-lg border border-blue-100 hover:shadow-md transition-all group" :style="{ backgroundColor: ad.bg }">
                    <div class="flex items-center gap-2 mb-1.5">
                      <span class="w-5 h-5 rounded bg-white/50 text-blue-600 flex items-center justify-center text-[10px] font-bold">Ad</span>
                      <span class="font-bold text-xs text-gray-900 group-hover:text-blue-700">{{ ad.name }}</span>
                    </div>
                    <p class="text-[11px] leading-snug text-slate-600">{{ ad.copy }}</p>
                 </a>
              </div>
            </div>
          </Transition>
        </aside>

      </div>
    </main>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted } from 'vue'
import allStartups from '~/content/startups.json'

const search = ref('')
const activeCategory = ref('All')
const sortBy = ref('MRR') 

// --- HELPER: Parse Revenue Text to Number ---
const parseRev = (str) => {
    if (!str) return 0;
    let s = str.toLowerCase().replace(/[^0-9.km]/g, '');
    let multiplier = 1;
    if (s.includes('k')) { multiplier = 1000; s = s.replace('k', ''); }
    if (s.includes('m')) { multiplier = 1000000; s = s.replace('m', ''); }
    return parseFloat(s) * multiplier || 0;
}

// --- CATEGORY MAPPING LOGIC ---
// 1. We list the visual labels you want.
// 2. We scan your JSON data to find the matching "Real Name".
// 3. We map them together.

const desiredCategories = [
  { label: 'ai', keywords: ['artificial intelligence', 'ai', 'bot'] },
  { label: 'dev-tools', keywords: ['developer', 'dev tool', 'api'] },
  { label: 'marketing', keywords: ['marketing', 'seo', 'email'] },
  { label: 'ecom', keywords: ['e-commerce', 'shopify', 'store'] },
  { label: 'saas', keywords: ['saas', 'software'] },
  { label: 'content', keywords: ['content', 'writing', 'video'] }
]

// Dynamically build the navigation based on real data in startups.json
const navCategories = computed(() => {
  // Get unique categories from data
  const availableCategories = [...new Set(allStartups.map(s => s.category).filter(Boolean))]
  
  const mapped = []
  
  desiredCategories.forEach(desired => {
    // Find a real category that matches one of the keywords
    const realMatch = availableCategories.find(realCat => 
      desired.keywords.some(k => realCat.toLowerCase().includes(k))
    )
    
    // If we found a match in the JSON, add it to our nav
    if (realMatch) {
      mapped.push({
        original: realMatch, // The exact string in the JSON (e.g. "Artificial Intelligence")
        display: desired.label // The visual text (e.g. "ai")
      })
    }
  })
  
  return mapped
})


// --- FILTERING & SORTING ---
const filteredStartups = computed(() => {
  let result = [...allStartups]

  // 1. Filter Category
  if (activeCategory.value !== 'All') {
    // Exact match on the "original" category name found in JSON
    result = result.filter(s => s.category === activeCategory.value)
  }

  // 2. Filter Search
  if (search.value) {
    const q = search.value.toLowerCase()
    result = result.filter(s => (s.company_name?.toLowerCase().includes(q)) || (s.tagline?.toLowerCase().includes(q)))
  }

  // 3. Sort
  if (sortBy.value === 'MRR') {
     result.sort((a, b) => (b.mrr_normalized || parseRev(b.mrr)) - (a.mrr_normalized || parseRev(a.mrr)))
  } else {
     result.sort((a, b) => parseRev(b.total_revenue) - parseRev(a.total_revenue))
  }

  return result
})

const resetFilters = () => {
  search.value = ''
  activeCategory.value = 'All'
}

// --- ADVERTISING SYSTEM ---
const bluePalette = [ '#eff6ff', '#dbeafe', '#e0f2fe', '#cffafe', '#e0e7ff' ]

const adInventory = Array.from({ length: 20 }, (_, i) => ({
  id: i,
  name: `Advertiser ${i + 1}`,
  emoji: ['🚀', '⚡', '🔥', '💎'][i % 4],
  copy: 'Increase your MRR by 30% in 30 days.',
  bg: bluePalette[i % 5]
}))

const adGroupIndex = ref(0)
let adInterval = null

const currentLeftAds = computed(() => adInventory.slice(adGroupIndex.value === 0 ? 0 : 10, adGroupIndex.value === 0 ? 5 : 15))
const currentRightAds = computed(() => adInventory.slice(adGroupIndex.value === 0 ? 5 : 15, adGroupIndex.value === 0 ? 10 : 20))

onMounted(() => {
  adInterval = setInterval(() => { adGroupIndex.value = adGroupIndex.value === 0 ? 1 : 0 }, 12000)
})

onUnmounted(() => { if (adInterval) clearInterval(adInterval) })
</script>

<style scoped>
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.8s ease-in-out;
}
.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}
</style>